﻿(function () {

    /* @ngInject */
    angular.module('app.physics').directive("physicsBody", physicsBody);

    /* @ngInject */
    function physicsBody(Physics) {
        var directive = {
            restrict: "E",
            require: "^physicsCanvas",
            scope: {
                options: "=",
                body: "=",
                type: "@"
            },
            link: function (scope, element, attributes, canvas) {
                scope.body = Physics.body(scope.type, scope.options);
                canvas.add(scope.body);
            }
        };
        return directive;
    }
})();
