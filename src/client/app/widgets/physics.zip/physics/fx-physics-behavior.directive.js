﻿(function (module) {

    angular.module('app.physics').directive("physicsBehavior", physicsBehavior);

    /* @ngInject */
    function physicsBehavior(Physics) {
        var directive = {

            restrict: "E",
            require: "^physicsCanvas",
            scope: {
                name: "@"
            },
            link: function (scope, element, attributes, canvas) {
                canvas.add(Physics.behavior(scope.name));
            }
        };
        return directive;
    }
})();
